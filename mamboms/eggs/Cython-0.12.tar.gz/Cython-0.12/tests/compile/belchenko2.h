void c_func(unsigned char pixel);
