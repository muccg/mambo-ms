INSTALLED_APPS = (
    'parent.*',
)
