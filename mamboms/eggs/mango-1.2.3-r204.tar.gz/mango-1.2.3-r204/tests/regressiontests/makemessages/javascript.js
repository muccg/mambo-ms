// '
gettext('This literal should be included.')
// '
gettext('This one as well.')
