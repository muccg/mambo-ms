from django.contrib.flatpages.tests.csrf import *
from django.contrib.flatpages.tests.middleware import *
from django.contrib.flatpages.tests.views import *
