from django.conf.urls.defaults import patterns, url
from django.core.exceptions import FieldError
from django.db import transaction
from django.http import HttpResponse, HttpResponseBadRequest, HttpResponseNotAllowed, HttpResponseNotFound, HttpResponseServerError
from django.utils.encoding import smart_str
from json import dumps, loads


class ExtJsonInterface(object):
    """
    A mixin that can be dropped into a ModelAdmin to provide a Web service
    which implements the semantics of the ExtJS JsonStore, JsonReader and
    JsonWriter objects, provided they're constructed with the restful option on
    and the encode option off.

    Note that this needs to be defined in the class inheritance list before
    ModelAdmin to ensure methods are called in the correct order.

    The records that can be manipulated through this interface can be
    restricted by defining the queryset() function on the ModelAdmin, since the
    result of that function is used as the basis for any further filtering and
    manipulation.
    """

    CONTENT_TYPE = "application/json; charset=UTF-8"

    def serialise(self, records):
        """
        The default serialiser: given an iterable of records, this function
        returns a JSON encoded array including the metadata that ExtJS expects
        to set the relevant field types.

        Internally, this calls serialise_fields, which may be defined on a
        model to return the ExtJS data types for each field.
        """

        def field_to_ext_type(field):
            internal_type = field.get_internal_type()

            # Obviously this isn't terribly comprehensive: string types can go
            # through as "auto", and field types beyond the standard set in
            # Django 1.2 aren't going to be handled gracefully. Still, it's a
            # start.
            MAPPING = {
                "AutoField": "int",
                "BigIntegerField": "int",
                "BooleanField": "boolean",
                "DateField": "date",
                "DateTimeField": "date",
                "FloatField": "float",
                "IntegerField": "int",
                "NullBooleanField": "boolean",
                "PositiveIntegerField": "int",
                "PositiveSmallIntegerField": "int",
                "SmallIntegerField": "int",
                "TimeField": "date",
            }

            if internal_type in MAPPING:
                return MAPPING[internal_type]

            return "auto"

        rows = []
        for record in records:
            rows.append(self.serialise_record(record))

        def serialise_fields(model):
            """
            Default field metadata generator. Given a model, this will return
            an array of field definitions that can be given to ExtJS within the
            metadata element.

            This can be overridden on a model by model basis by defining a
            serialised_fields() method on that model.
            """

            fields = []

            for field in model._meta.fields:
                fields.append({
                    "name": field.name,
                    "type": field_to_ext_type(field),
                })

                try:
                    field.rel.to
                    fields.append({
                        "name": field.name + "__unicode",
                        "type": "string",
                    })
                except AttributeError:
                    pass

            return fields

        try:
            if callable(self.model.serialised_fields):
                fields = self.model.serialised_fields()
            else:
                fields = serialise_fields(self.model)
        except AttributeError:
            fields = serialise_fields(self.model)

        metadata = {
            "root": "rows",
            "idProperty": self.model._meta.pk.name,
            "successProperty": "success",
            "fields": fields
        }

        obj = {
            "metaData": metadata,
            "rows": rows,
        }

        return dumps(obj, indent=4, ensure_ascii=False)


    def serialise_record(self, record):
        """
        Takes a record and turns it into a dict representing the fields on that
        record. By default, this calls an inner function to do this in a
        standard way; models can override this by defining a serialise()
        method.

        Generally, this function shouldn't need to be called directly, since
        serialise() will call this as appropriate.
        """

        def serialise_record(record):
            d = {}

            for field in record._meta.fields:
                # It's helpful to return both the primary key and string
                # representation of foreign keys.
                value = getattr(record, field.name)
                try:
                    # Test to see if we have a foreign key relationship.
                    field.rel.to

                    # The value might actually be None if it's nullable.
                    try:
                        d[field.name] = value.pk
                        d[field.name + "__unicode"] = unicode(value)
                    except AttributeError:
                        d[field.name] = None
                        d[field.name + "__unicode"] = u""
                except AttributeError:
                    # No foreign key relationship.
                    d[field.name] = unicode(value)

            return d

        serialiser = serialise_record
        try:
            if callable(self.model.serialise):
                serialiser = lambda record: record.serialise()
        except AttributeError:
            pass

        return serialiser(record)


    def set_field(self, instance, field, value):
        """
        Set a field on an instance of the ModelAdmin's model while
        respecting foreign keys. Surely there's an easier way to do this in
        Django, but I'll be damned if I can figure out how.
        """

        # Check if it's a foreign key: if so, we have to
        # instantiate the right object first.
        model_field = self.model._meta.get_field_by_name(field)[0]

        try:
            foreign_class = model_field.rel.to
            actual = foreign_class.objects.get(pk=value)
        except AttributeError:
            actual = value

        setattr(instance, field, actual)


    def handle_create(self, request):
        """
        Request handler for create requests. This will handle POST requests of
        both JSON and URL encoded data.
        """

        o = self.model()
        
        # Pull in the JSON data that's been sent, if it is in fact JSON.
        try:
            row = loads(request.raw_post_data)["rows"]

            try:
                for field in row:
                    self.set_field(o, field, row[field])
            except Exception, e:
                print e

                response = {
                    "success": False,
                    "message": "Unable to parse incoming record.",
                }

                return HttpResponseBadRequest(content_type=self.CONTENT_TYPE, content=dumps(response))
        except ValueError:
            # If it's not JSON, then it's probably URL encoded, and if it's
            # not, we're not going to know how to deal with it anyway.
            for field in request.POST:
                self.set_field(o, field, request.POST[field])
        except KeyError:
            response = {
                "success": False,
                "message": "Unable to parse incoming record.",
            }

            return HttpResponseBadRequest(content_type=self.CONTENT_TYPE, content=dumps(response))

        o.save(force_insert=True)

        response = {
            "success": True,
            "message": "Created new record.",
            "data": self.serialise_record(o),
        }

        return HttpResponse(content_type=self.CONTENT_TYPE, content=dumps(response))


    def handle_delete(self, request, id):
        """
        Request handler for delete requests.
        """

        try:
            o = self.queryset(request).get(pk=id)
            o.delete()

            response = {
                "success": True,
                "message": "Record deleted.",
            }

            return HttpResponse(content_type=self.CONTENT_TYPE, content=dumps(response))
        except self.model.DoesNotExist:
            response = {
                "success": False,
                "message": "The record could not be found.",
            }
            
            return HttpResponseNotFound(content_type=self.CONTENT_TYPE, content=dumps(response))


    def handle_read(self, request):
        """
        Request handler for read requests. This supports arbitrary filters
        which will be given to the queryset filter() function as keyword
        arguments, and also sort and dir GET parameters, which will be used to
        influence sorting. This allows the remoteSort parameter to be turned on
        within the ExtJS JsonStore object.

        This function will ignore a GET parameter called _dc to be compatible
        with Prototype, which may be used via an adapter within ExtJS. Other
        invalid filters will result in 400 responses.
        """

        qs = self.queryset(request)

        # Add filters.
        filters = {}
        for field, term in request.GET.iteritems():
            if field not in ("sort", "dir", "_dc"):
                filters[smart_str(field)] = term

        if len(filters) > 0:
            try:
                qs = qs.filter(**filters)
            except FieldError:
                # Bad parameter to QuerySet.filter.
                return HttpResponseBadRequest(content_type=self.CONTENT_TYPE, content=dumps("Bad search term"))

        # Apply sorting parameters, if given.
        if "sort" in request.GET and "dir" in request.GET:
            field = request.GET["sort"]
            if request.GET["dir"].lower() == "desc":
                field = "-" + field
            qs = qs.order_by(field)

        return HttpResponse(content_type=self.CONTENT_TYPE, content=self.serialise(qs))


    @transaction.commit_manually
    def handle_update(self, request, id):
        """
        Request handler for update requests. This function only supports JSON
        request bodies.

        Updates take place within a single transaction, so updates are
        guaranteed to be atomic -- if an error is returned, then the update is
        guaranteed not to have succeeded.
        """

        try:
            # Grab the name of the primary key field.
            pk = self.model._meta.pk.name

            # Pull in the JSON data that's been sent.
            row = loads(request.raw_post_data)["rows"]
            qs = self.queryset(request)

            # OK, retrieve the object and update the field(s).
            o = qs.get(pk=row[pk])
            for name, value in row.iteritems():
                if name != pk:
                    self.set_field(o, name, value)
            o.save()

            # If we've gotten here, all is well.
            transaction.commit()

            response = {
                "success": True,
            }

            return HttpResponse(content_type=self.CONTENT_TYPE, content=dumps(response))
        except self.model.DoesNotExist:
            transaction.rollback()

            response = {
                "success": False,
                "message": "The record could not be found.",
            }
            
            return HttpResponseNotFound(content_type=self.CONTENT_TYPE, content=dumps(response))
        except KeyError:
            transaction.rollback()

            response = {
                "success": False,
                "message": "An internal error occurred.",
            }
            
            return HttpResponseServerError(content_type=self.CONTENT_TYPE, content=dumps(response))

    
    def get_urls(self):
        """
        Override for ModelAdmin.get_urls() to add the appropriate URL routing
        for the Web service calls.
        """

        urls = super(ExtJsonInterface, self).get_urls()
        local_urls = patterns("",
            url(r"^ext/json/{0,1}$", self.admin_site.admin_view(self.root_dispatcher)),
            url(r"^ext/json/(?P<id>[0-9]+)$", self.admin_site.admin_view(self.id_dispatcher)),
        )

        return local_urls + urls


    def id_dispatcher(self, request, id):
        """
        Dispatcher for requests that include a record ID, which in ExtJS land
        mean requests to update or delete a record via the PUT and DELETE
        methods, respectively.
        """

        if request.method == "PUT":
            return self.handle_update(request, id)
        elif request.method == "DELETE":
            return self.handle_delete(request, id)
        else:
            return HttpResponseNotAllowed(["PUT", "DELETE"])


    def root_dispatcher(self, request):
        """
        Dispatcher for requests that don't include a record ID. These may be
        read or create requests via the GET and POST methods, respectively.
        """

        if request.method == "GET":
            return self.handle_read(request)
        elif request.method == "POST":
            return self.handle_create(request)
        else:
            # Unknown method.
            return HttpResponseNotAllowed(["GET", "POST"])
